export class Users {
    userId:number;
    id : number;
    title:string;
    body :string

    constructor(userId:any,id:any,title:any,body:any){

       this.userId=userId;
       this.id=id;
       this.title=title;
       this.body=body;


}
}
