import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Users } from '../users';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http : HttpClient) { }
  url:string="https://jsonplaceholder.typicode.com/posts"
//  getData():Observable<any>{
 //   const url="https://jsonplaceholder.typicode.com/posts"
 //   return this.http.get<any>(url)
 // }
 getUsers()
 {
   return this.http.get<Users[]>(this.url)
 }

}
