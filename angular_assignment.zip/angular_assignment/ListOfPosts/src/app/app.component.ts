import { Component, OnInit } from '@angular/core';
import { NEVER } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { UsersService } from './services/users.service';
import { Users } from './users';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  /**   data :Array<any> 
  constructor(private _UserService: UsersService) { 
    this.data=new Array<any>()
  }

      getData(){
        this._UserService.getData().subscribe((data)=>{
          console.log(data)
          this.data=data
        })
      }
**/
users:Users[]=[];
p: number=1;
constructor(public us:UsersService)
{

}
ngOnInit():void
{
 this.us.getUsers().subscribe((response) => {
   this.users=response;
 })

  }
}
