import { NONE_TYPE } from '@angular/compiler';
import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 /**  title = 'AngularForm'; **/
  states=["Andhra Pradesh","Arunachal Pradesh","Assam","Bihar", "Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh", "Jammu and Kashmir",
  "Jharkhand","Karnataka","Kerala", "Madhya Pradesh", "Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland",
  "Odisha","Punjab","Rajasthan", "Sikkim","Tamil Nadu","Telangana", "Tripura","Uttarakhand","Uttar Pradesh", "West Bengal",
  "Andaman and Nicobar Islands","Chandigarh", "Dadra and Nagar Haveli","Daman and Diu", "Delhi", "Lakshadweep",
  "Puducherry"];
  stateHasError=true;
  EmployeeModel = new  Employee('','','','','default','','','','');

  validateState(value:any)
  {
    if(value==='default')
    {
      this.stateHasError=true;
    }
    else{
      this.stateHasError=false;
    }
  }
 // selected : string='AndhraPradesh'
onSubmit()
{
  console.log(this.EmployeeModel)
}
 
}
