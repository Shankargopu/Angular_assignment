export class Employee {
  constructor(
       public FirstName : string,
       public LastName : string,
       public Address : string,
       public City : string,
       public state : string,

       public Zip : string,
      // public DOB : Date,
      // public  selected : string='AndhraPradesh',
       public PhoneNumber : string,
       public DOB : string,
       //public DateOfBirth : Date,
       public Email : string
  ){}

}


